export function Input(props){return <input className='input' {...props}/>}
