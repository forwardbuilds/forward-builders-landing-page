export function Textarea(props){return <textarea className='textarea' {...props}/>}
