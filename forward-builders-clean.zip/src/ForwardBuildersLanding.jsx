import { useState } from "react";
import { Button } from "@/components/ui/button";
import { Card, CardContent } from "@/components/ui/card";
import { Input } from "@/components/ui/input";
import { Textarea } from "@/components/ui/textarea";
import { Phone, Hammer, Paintbrush, Zap, MoreHorizontal, Quote } from "lucide-react";

export default function ForwardBuildersLanding() {
  const [showToast, setShowToast] = useState(false);

  const handleSubmit = (e) => {
    e.preventDefault();
    const name = e.target.name.value;
    const phone = e.target.phone.value;
    const email = e.target.email?.value || "";
    const message = e.target.message.value;
    const subject = encodeURIComponent("New Contact Form Submission");
    const body = encodeURIComponent(`Name: ${name}\nPhone: ${phone}\nEmail: ${email}\nMessage: ${message}`);
    window.location.href = `mailto:forwardbuilds@gmail.com?subject=${subject}&body=${body}`;
    setShowToast(true);
    setTimeout(() => setShowToast(false), 4000);
  };

  const goContact = (e) => {
    e?.preventDefault?.();
    const target = document.getElementById("contact");
    if (target) target.scrollIntoView({ behavior: "smooth", block: "start" });
  };

  const services = [
    { icon: <Hammer className="h-10 w-10 mb-2 text-[#FFD700]" />, title: "Kitchen & Bath", desc: "Design, plumbing, tile, finishes — clean work, clear timelines." },
    { icon: <Hammer className="h-10 w-10 mb-2 text-[#FFD700]" />, title: "Framing & Drywall", desc: "New walls, pocket doors, layout changes, drywall install & finishing." },
    { icon: <Paintbrush className="h-10 w-10 mb-2 text-[#FFD700]" />, title: "Interior Painting", desc: "Pro prep, clean edges, top-quality finishes for every room." },
    { icon: <Zap className="h-10 w-10 mb-2 text-[#FFD700]" />, title: "Electrical", desc: "Outlets, lighting upgrades, troubleshooting — safe & to code." },
    { icon: <MoreHorizontal className="h-10 w-10 mb-2 text-[#FFD700]" />, title: "...and Much More", desc: "Flooring, doors, minor repairs, guidance — ask about your project." }
  ];

  const testimonials = [
    { name: "Sarah M.", location: "Park Slope", quote: "Forward made our kitchen remodel stress‑free. The crew was respectful, the schedule stayed on track, and the final result exceeded expectations." },
    { name: "James L.", location: "Windsor Terrace", quote: "They guided us through every step and even told us what we didn’t need to spend on — saving thousands. Honest, straightforward, and reliable." },
    { name: "Elena R.", location: "Williamsburg", quote: "The site was spotless every evening and communication was constant. We felt comfortable leaving them in the house while we were out." },
    { name: "Marcus T.", location: "Brooklyn Heights", quote: "Their painting team was meticulous. Every wall was perfectly prepped, edges were sharp, and the finish looks incredible — completely transformed our space." }
  ];

  return (
    <div className="min-h-screen bg-white text-[#001F3F]">
      {/* Toast */}
      {showToast && (
        <div className="fixed bottom-4 right-4 bg-green-600 text-white py-3 px-5 rounded-xl shadow-lg">
          ✅ Thank you! Someone will get back to you shortly.
        </div>
      )}

      {/* HERO WITH SINGLE YELLOW BUTTON & CONTACT FORM */}
      <section className="bg-[#001F3F] text-white">
        <div className="max-w-7xl mx-auto px-6 py-10 grid md:grid-cols-2 gap-8 items-center">
          {/* Left: headline & primary action */}
          <div>
            <h1 className="text-4xl md:text-5xl font-extrabold leading-snug">
              Brooklyn Renovations, Done Right — <span className="text-[#FFD700]">or We’ll Connect You to Someone You Can Trust</span>
            </h1>
            <p className="mt-4 text-lg md:text-xl text-gray-100">
              We protect homeowners from upsells and surprises. Clear scopes, clean work, and honest guidance from first call to final walkthrough.
            </p>
            <div className="mt-6">
              <a href="sms:+19175483311">
                <Button className="bg-[#FFD700] text-[#001F3F] font-bold rounded-2xl w-full md:w-auto px-10 py-5 text-lg hover:!bg-[#FFD700] hover:!text-[#001F3F] focus-visible:!bg-[#FFD700] active:!bg-[#FFD700]">
                  Prefer texting? Text Us at 917‑548‑3311
                </Button>
              </a>
            </div>
          </div>

          {/* Right: contact form */}
          <Card className="border-[#FFD700] h-full">
            <CardContent className="p-5 bg-white text-[#001F3F] rounded-xl h-full flex flex-col justify-center">
              <div className="text-lg font-semibold mb-3">Contact Us</div>
              <form className="grid grid-cols-1 gap-2" onSubmit={handleSubmit}>
                <Input name="name" placeholder="Your name" />
                <Input name="phone" type="tel" placeholder="Phone number" />
                <Input name="email" type="email" placeholder="Email (optional)" />
                <Textarea name="message" rows={3} placeholder="Tell us about your project" />
                <Button type="submit" className="bg-[#001F3F] rounded-2xl">Send</Button>
              </form>
            </CardContent>
          </Card>
        </div>
      </section>

      {/* SERVICES */}
      <section id="services" className="max-w-7xl mx-auto px-6 py-10">
        <div className="text-center mb-8">
          <h2 className="text-3xl md:text-5xl font-extrabold">Renovations & Guidance</h2>
          <p className="text-gray-700 mt-3 text-lg md:text-xl max-w-3xl mx-auto leading-snug">
            From full remodels to honest step‑by‑step guidance on contracts and renovation choices, so you’re never left guessing.
          </p>
        </div>
        {/* Force 5 equal columns, no stacking */}
        <div className="grid grid-cols-5 gap-3 items-stretch">
          {services.map((service, idx) => (
            <a href="#contact" onClick={goContact} key={idx}>
              <Card className="h-48 w-full rounded-xl shadow-md bg-gray-50 flex flex-col justify-center items-center transform transition duration-300 hover:scale-105 hover:shadow-xl cursor-pointer text-center">
                <CardContent className="p-3 flex flex-col items-center justify-center text-center h-full w-full">
                  {service.icon}
                  <div className="font-bold text-sm mt-1">{service.title}</div>
                  <p className="text-gray-600 text-xs mt-1 leading-snug text-center">{service.desc}</p>
                </CardContent>
              </Card>
            </a>
          ))}
        </div>
      </section>

      {/* TESTIMONIALS */}
      <section id="testimonials" className="bg-gray-50 py-14">
        <div className="max-w-6xl mx-auto px-4 text-center">
          <h2 className="text-3xl md:text-4xl font-extrabold mb-10">Homeowners Trust Forward</h2>
          <div className="grid md:grid-cols-4 gap-6">
            {testimonials.map((t, i) => (
              <Card key={i} className="rounded-xl shadow-md bg-white border border-gray-100">
                <CardContent className="p-6 flex flex-col items-center justify-between text-center h-full">
                  <Quote className="w-6 h-6 text-[#FFD700] mb-3" />
                  <p className="text-gray-700 text-sm italic mb-4">“{t.quote}”</p>
                  <div className="text-xs font-semibold text-gray-500">— {t.name}, {t.location}</div>
                </CardContent>
              </Card>
            ))}
          </div>
        </div>
      </section>

      {/* CONTACT SECTION (ANCHOR FOR CARD LINKS) */}
      <section id="contact" className="bg-[#001F3F] text-white py-14">
        <div className="max-w-6xl mx-auto px-4 grid md:grid-cols-2 gap-10 items-center">
          <div>
            <h2 className="text-3xl md:text-4xl font-extrabold">Tell Us About Your Project</h2>
            <p className="text-gray-200 mt-3">Prefer texting? <a className="underline" href="sms:+19175483311">Text 917‑548‑3311</a>. We usually reply the same day.</p>
          </div>
          <Card className="border-[#FFD700]">
            <CardContent className="p-6 bg-white text-[#001F3F] rounded-xl">
              <form className="grid grid-cols-1 gap-3" onSubmit={handleSubmit}>
                <Input name="name" placeholder="Your name" />
                <Input name="phone" type="tel" placeholder="Phone number" />
                <Textarea name="message" rows={4} placeholder="What are you planning?" />
                <Button type="submit" className="bg-[#001F3F] rounded-2xl">Send</Button>
              </form>
            </CardContent>
          </Card>
        </div>
      </section>

      {/* FOOTER */}
      <footer className="border-t border-gray-200">
        <div className="max-w-6xl mx-auto px-4 py-8 text-sm text-gray-600 flex flex-wrap items-center justify-between gap-3">
          <div>© {new Date().getFullYear()} Forward Renovations. All rights reserved.</div>
          <div className="flex items-center gap-4">
            <a href="tel:19175483311" className="flex items-center gap-1"><Phone className="w-4 h-4"/> 917‑548‑3311</a>
            <span>Brooklyn, NY</span>
          </div>
        </div>
      </footer>
    </div>
  );
}
